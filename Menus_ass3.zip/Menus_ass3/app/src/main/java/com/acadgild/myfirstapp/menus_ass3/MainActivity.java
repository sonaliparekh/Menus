package com.acadgild.myfirstapp.menus_ass3;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menus, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //TextView textView = (TextView)findViewById(R.id.textt);
        switch (item.getItemId()) {
            case R.id.colors:
                PopupMenu popupMenu = new PopupMenu(MainActivity.this,findViewById(R.id.colors));
                Menu menu = popupMenu.getMenu();
                menu.add(Menu.NONE,11,0,"RED");
                menu.add(Menu.NONE,12,1,"BLUE");
                menu.add(Menu.NONE,13,2,"GREEN");
                menu.add(Menu.NONE, 14, 3, "ORANGE");
                menu.add(Menu.NONE, 15, 4, "BLACK");
                //Toast.makeText(MainActivity.this, "Colors seelcted ", Toast.LENGTH_SHORT).show();
                popupMenu.show();

            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    TextView textView = (TextView)findViewById(R.id.textt);
                    switch (item.getItemId())
                    {
                        case 11:
                            textView.setBackgroundColor(Color.RED);
                            Toast.makeText(MainActivity.this,"Red selected",Toast.LENGTH_SHORT).show();
                            return true;
                        case 12:
                            textView.setBackgroundColor(Color.BLUE);
                            Toast.makeText(MainActivity.this,"blue selected",Toast.LENGTH_SHORT).show();
                            return true;
                        case 13:
                            textView.setBackgroundColor(Color.GREEN);
                            Toast.makeText(MainActivity.this,"green selected",Toast.LENGTH_SHORT).show();
                            return true;
                        case 14:
                            textView.setBackgroundColor(Color.YELLOW);
                            Toast.makeText(MainActivity.this,"black selected",Toast.LENGTH_SHORT).show();
                            return true;
                        case 15:
                            textView.setBackgroundColor(Color.BLACK);
                            Toast.makeText(MainActivity.this,"Red selected",Toast.LENGTH_SHORT).show();
                            return true;


                    }
                    return false;
                }
            });
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

}

