package com.acadgild.myfirstapp.menusdemo;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by E9900317 on 4/3/2016.
 */
public class SecondActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}
