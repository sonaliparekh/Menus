package com.acadgild.myfirstapp.menusdemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //TextView textView = (TextView)findViewById(R.id.text);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //TextView textView = (TextView)findViewById(R.id.textview);
        Button button = (Button)findViewById(R.id.button1);
        registerForContextMenu(button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openContextMenu(v);
            }
        });

        final Button button2 = (Button)findViewById(R.id.button2);
        final PopupMenu popupMenu = new PopupMenu(MainActivity.this,button2, Gravity.TOP);
        Menu menu = popupMenu.getMenu();
        menu.add(Menu.NONE,11,0,"New");
        menu.add(Menu.NONE,12,1,"Open");
        menu.add(Menu.NONE, 13, 2, "Edit");
        menu.add(Menu.NONE, 14, 3, "Close");
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupMenu.show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.help:
                Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                startActivity(intent);
      //          textView.setText("New");
                return true;
            case R.id.about:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
        public boolean onCreateOptionsMenu(Menu menu) {

            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menus, menu);
            return super.onCreateOptionsMenu(menu);
        }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("context menu");
        menu.add(0,11,0,"neww");
        menu.add(0,12,0,"open");
        menu.add(0,13,0,"edit");
        menu.add(0,14,0,"close");
        menu.add(0,15,0,"exit");
    }



    /*
        ListView lv =(ListView)findViewById(R.id.listview);

         String[] dataarray ={"January","February","March"};
        ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.activity_list_item,dataarray);
        lv.setAdapter(adapter);
        /*listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this,dataarray[position],Toast.LENGTH_SHORT).show();
            }
        });
        */


    }

