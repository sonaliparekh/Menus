package com.acadgild.myfirstapp.customlistview;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.widget.CursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Context context;
    String selectedPh;
    private String phno = null;
    private long id = -1L;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final String[] name = {" Sonali","Shreya","Priya","Khush","Tanay","Devang","Ankit"};
        String[] phno = {"9420033165","9923004021","9923003292","9960869365","9405567416","7276826040","9405570507","9422080665","9860019001","9423791917"};
        CutsomList cutsomList = new CutsomList(MainActivity.this,name,phno);
        final ListView listView = (ListView)findViewById(R.id.listvieww);
        listView.setAdapter(cutsomList);
                 registerForContextMenu(listView);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //String sel = name[+position];
                //Toast.makeText(MainActivity.this,sel,Toast.LENGTH_SHORT).show();
                TextView tphno = (TextView)view.findViewById(R.id.phone);
                selectedPh=tphno.getText().toString();
                openContextMenu(listView);

            }
        });

    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        //phno = ((TextView)info.targetView.findViewById(R.id.phone)).getText().toString();
        //id = info.id;
       //Adapter a  = getListAdapter();
        //ListView lv = (ListView)v;
        //AdapterView.AdapterContextMenuInfo acmi = (AdapterView.AdapterContextMenuInfo)menuInfo;
        //acmi  = ()lv.getItemAtPosition(acmi.position);
        menu.setHeaderTitle("Perform Operation");
        menu.add(0, 11, 0, "Call");
        menu.add(0,12,0,"Message");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case 11:
                //AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
                //phno = ((TextView)info.targetView.findViewById(R.id.phone)).getText().toString();
                //to create an intent
               Toast.makeText(this, "Calling " + selectedPh, Toast.LENGTH_SHORT).show();
                Intent call = new Intent(Intent.ACTION_CALL).setData(Uri.parse(selectedPh));
                //call.setAction();
                startActivity(call);
                return true;
            case 12:
                Toast.makeText(this,"Messaging" + selectedPh,Toast.LENGTH_SHORT).show();
                Intent sms = new Intent(Intent.ACTION_VIEW, Uri.parse(selectedPh));
                //sms.setAction();
                //sms.setData(Uri.parse(selectedPh));
                startActivity(sms);
                return true;

            default:
                return super.onContextItemSelected(item);
        }


    }
}
